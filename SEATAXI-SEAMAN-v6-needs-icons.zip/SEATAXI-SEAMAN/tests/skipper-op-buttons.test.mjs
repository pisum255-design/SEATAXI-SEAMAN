// Skipper operation card: no extra "record event" card, new pause / end icons, event shortcut still present.
import { createRequire } from 'node:module';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const require = createRequire(import.meta.url);
const { chromium } = require(process.env.PLAYWRIGHT_PATH || 'playwright');
const here = path.dirname(fileURLToPath(import.meta.url));
let pass = 0, fail = 0;
const ok = (n, c, x='') => { if (c) pass++; else { fail++; console.log('FAIL ' + n + ' ' + x); } };
const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 376, height: 800 } });
const errors = []; page.on('pageerror', e => errors.push(String(e)));
await page.addInitScript(() => { window.Capacitor = { isNativePlatform: () => false, Plugins: {} }; });
await page.goto('file://' + path.join(here, '..', 'www', 'index.html')); await page.waitForTimeout(300);
await page.evaluate(() => {
  state.permissionsIntroShown = true; state.profile = { name: 'Ibrahim', rank: 'SKIPPER', photo: null }; state.settings.language = 'en';
  state.currentBoat = 'SEATAXI V'; ensureBoat('SEATAXI V');
  const id = 'opx'; state.operations[id] = { id, boat: 'SEATAXI V', startTime: new Date().toISOString(), status: 'inaendelea', trips: [], incidents: [] };
  state.activeOperationId = id; nav.tab = 'dashboard'; render();
});
await page.waitForTimeout(300);
ok('no REKODI/record-event card in operation card', await page.$('#recordEventBtn') === null);
ok('record event text absent from operation card', !/RECORD EVENT \/ EMERGENCY|REKODI TUKIO \/ DHARURA/i.test(await page.evaluate(() => document.getElementById('screenRoot').innerText)));
ok('event shortcut still present alongside other shortcuts', await page.$('#skShEvent') !== null && (await page.$$('.shortcuts-grid-4 .shortcut-btn')).length === 4);
const pause = await page.$eval('#pauseOpBtn', e => ({ svg: !!e.querySelector('.btn-ic svg'), emoji: /⏸/.test(e.textContent), txt: e.textContent.trim() }));
ok('pause uses new icon, no emoji', pause.svg && !pause.emoji && /PAUSE OPERATION|SIMAMISHA OPERATION/i.test(pause.txt), JSON.stringify(pause));
const end = await page.$eval('#endOpBtn', e => ({ svg: !!e.querySelector('.btn-ic svg'), emoji: /🔴/.test(e.textContent), txt: e.textContent.trim(), paths: e.querySelectorAll('svg path').length }));
ok('end uses tick icon, no red dot', end.svg && !end.emoji && end.paths >= 3 && /END OPERATION|MALIZA OPERATION/i.test(end.txt), JSON.stringify(end));
const sizes = await page.evaluate(() => ['pauseOpBtn', 'endOpBtn'].map(id => { const i = document.querySelector('#' + id + ' .btn-ic').getBoundingClientRect(); return [Math.round(i.width), Math.round(i.height)]; }));
ok('icons rendered with size', sizes.every(s => s[0] > 12 && s[1] > 12), JSON.stringify(sizes));
// handlers still work: pause -> resume button appears
await page.click('#pauseOpBtn'); await page.waitForTimeout(300);
ok('pause still works', await page.evaluate(() => state.operations['opx'].status) === 'imesimamishwa');
await page.screenshot({ path: '/tmp/sk-ops.png' });
ok('no page errors', errors.length === 0, errors.join('|'));
await browser.close();
console.log(`skipper-op-buttons.test.mjs: ${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
