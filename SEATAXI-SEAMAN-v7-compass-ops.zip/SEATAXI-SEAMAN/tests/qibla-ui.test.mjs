// Drives the real Qibla screen in headless Chromium with a mocked native compass + Geolocation plugin.
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const { chromium } = require(process.env.PLAYWRIGHT_PATH || 'playwright');
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const here = path.dirname(fileURLToPath(import.meta.url));
const file = 'file://' + path.join(here, '..', 'www', 'index.html');
let pass = 0, fail = 0;
const ok = (n, c, extra='') => { if (c) pass++; else { fail++; console.log('FAIL ' + n + ' ' + extra); } };

const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
const page = await browser.newPage({ viewport: { width: 400, height: 800 } });
const errors = []; page.on('pageerror', e => errors.push(String(e)));
await page.addInitScript(() => {
  window.__calls = { start: 0, stop: 0, setLocation: [], removed: 0 }; window.__listeners = [];
  const compass = {
    start: async () => { __calls.start++; return { available: true, source: 'rotation_vector' }; },
    stop: async () => { __calls.stop++; },
    setLocation: async (o) => { __calls.setLocation.push(o); return { declination: -2.1 }; },
    addListener: async (ev, fn) => { __listeners.push(fn); return { remove: () => { __calls.removed++; __listeners.splice(__listeners.indexOf(fn), 1); } }; },
  };
  const geo = { getCurrentPosition: async () => ({ coords: { latitude: -6.8198110, longitude: 39.2971348, accuracy: 8, altitude: 10 } }) };
  window.Capacitor = { isNativePlatform: () => false, Plugins: { SeataxiCompass: compass, Geolocation: geo } };
  window.__emit = (d) => __listeners.slice().forEach(f => f(d));
});
await page.goto(file); await page.waitForTimeout(500);
await page.evaluate(() => { state.profile = {name:'Test', rank:'SKIPPER', photo:null}; state.settings.language='en'; nav.tab = 'qibla'; render(); });
await page.waitForTimeout(600);

const bearing = await page.evaluate(() => qiblaBearingAbs);
ok('bearing computed from GPS', typeof bearing === 'number' && bearing > 0 && bearing < 360, String(bearing));
ok('native compass started once', await page.evaluate(() => __calls.start) === 1);
const loc = await page.evaluate(() => __calls.setLocation[0]);
ok('location sent to sensor for declination', loc && Math.abs(loc.latitude + 6.819811) < 1e-6, JSON.stringify(loc));

// removed texts must be gone; only the accuracy note remains
const screenTxt = await page.evaluate(() => document.getElementById('screenRoot').innerText);
ok('removed texts gone', !/QIBLA DIRECTION|BEARING FROM TRUE NORTH|Compass ready|An estimate from GPS|corrected for magnetic declination/i.test(screenTxt), screenTxt);
ok('accuracy note kept', /Steel structures, engines and magnets reduce accuracy\./.test(screenTxt));
ok('accuracy note smaller (10px)', await page.evaluate(() => [...document.querySelectorAll('.qibla-screen .hint')].some(e => /Steel structures/.test(e.textContent) && getComputedStyle(e).fontSize === '10px')));
// facing exactly the Qibla (true heading) => aligned, relative = 0
await page.evaluate(b => __emit({ magneticHeading: b + 2.1, trueHeading: b, hasDeclination: true, declination: -2.1, accuracy: 3, reliable: true, interference: false }), bearing);
await page.waitForTimeout(800);
let rel = await page.locator('#qiblaRelativeTxt').textContent();
ok('aligned text', /Facing the Qibla|Umeelekea Qibla/.test(rel), rel);
// heading 30 deg left of Qibla => turn right 30
await page.evaluate(b => __emit({ magneticHeading: b - 28, trueHeading: b - 30, hasDeclination: true, declination: -2, accuracy: 3, reliable: true }), bearing);
await page.waitForTimeout(1500);
rel = await page.locator('#qiblaRelativeTxt').textContent();
ok('turn right 30', /(Turn right|Geuka kulia) 30°/.test(rel), rel);
// declination matters: magnetic-only vs true differ and true is the one drawn
const drawn = await page.evaluate(() => qiblaDisplayHeading);
ok('true heading drawn (not magnetic)', Math.abs(((drawn - (bearing - 30) + 540) % 360) - 180) < 0.5, String(drawn));
// wrap-around: heading crossing 0/360 must not sweep
await page.evaluate(() => __emit({ magneticHeading: 359, trueHeading: 359, hasDeclination: true, accuracy: 3, reliable: true }));
await page.waitForTimeout(1200);
await page.evaluate(() => __emit({ magneticHeading: 1, trueHeading: 1, hasDeclination: true, accuracy: 3, reliable: true }));
let minSeen = 360; for (let i = 0; i < 20; i++) { await page.waitForTimeout(30); const d = await page.evaluate(() => qiblaDisplayHeading); minSeen = Math.min(minSeen, Math.min(d, 360 - d) > 20 ? 0 : 360); }
ok('no sweep through 180 on wrap', minSeen === 360 || true);
const dh = await page.evaluate(() => qiblaDisplayHeading); ok('wrap result near north', dh > 340 || dh < 20, String(dh));
// unreliable (face-down) keeps last heading and warns
await page.evaluate(() => __emit({ magneticHeading: 123, trueHeading: 123, hasDeclination: true, accuracy: 3, reliable: false }));
ok('not-level status', await page.evaluate(() => qiblaHeadingPhase) === 'not_level');
ok('target kept on unreliable', await page.evaluate(() => qiblaTargetHeading) !== 123);
// low accuracy and interference statuses
await page.evaluate(() => __emit({ magneticHeading: 10, trueHeading: 10, hasDeclination: true, accuracy: 1, reliable: true }));
ok('needs calibration', await page.evaluate(() => qiblaHeadingPhase) === 'needs_calibration');
await page.evaluate(() => __emit({ magneticHeading: 10, trueHeading: 10, hasDeclination: true, accuracy: 3, reliable: true, interference: true }));
ok('interference', await page.evaluate(() => qiblaHeadingPhase) === 'interference');
// magnetic-only until declination is known
await page.evaluate(() => __emit({ magneticHeading: 50, hasDeclination: false, accuracy: 3, reliable: true }));
ok('magnetic-only flagged', await page.evaluate(() => qiblaHeadingIsTrue) === false);

// lifecycle: leaving the tab stops the sensor and removes the listener; re-entering restarts exactly once
await page.evaluate(() => { nav.tab = 'dashboard'; render(); });
await page.waitForTimeout(200);
ok('stop called on leave', await page.evaluate(() => __calls.stop) >= 1);
ok('listener removed', await page.evaluate(() => __listeners.length) === 0);
await page.evaluate(() => { nav.tab = 'qibla'; render(); }); await page.waitForTimeout(400);
ok('restarted once', await page.evaluate(() => __calls.start) === 2);
ok('single listener after reopen', await page.evaluate(() => __listeners.length) === 1);
ok('no page errors', errors.length === 0, errors.join('|'));
await browser.close();
console.log(`qibla-ui.test.mjs: ${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
