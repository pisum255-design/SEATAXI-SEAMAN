package com.azamseataxi.seaman;

/**
 * Pure-Java compass / Qibla mathematics. NO Android dependencies, so every
 * function here is unit-testable on a plain JVM (see tests/QiblaMathTest.java).
 *
 * Three quantities are deliberately kept apart and never mixed:
 *
 *  1. ABSOLUTE QIBLA BEARING  - geographic great-circle bearing from a place on
 *     Earth to the Kaaba, clockwise from TRUE north. Depends only on location.
 *  2. DEVICE HEADING          - which compass direction the phone is facing,
 *     clockwise from magnetic north (as sensed) and, once a declination is
 *     known, from true north.
 *  3. RELATIVE QIBLA ANGLE    - (1) minus (2), the angle the on-screen arrow is
 *     drawn at, clockwise from the direction the user is facing.
 *
 * World frame is East-North-Up (the frame of
 * SensorManager.getRotationMatrixFromVector). A row-major 3x3 matrix r maps a
 * device vector to world coordinates, so its COLUMNS are the device axes
 * expressed in the world:
 *   column 0 = device +X (right edge), column 1 = device +Y (top edge),
 *   column 2 = device +Z (screen normal, pointing out of the screen at the user)
 */
public final class QiblaMath {
    private QiblaMath() {}

    /** Kaaba (centre of the Masjid al-Haram courtyard), WGS84, decimal degrees. */
    public static final double KAABA_LAT = 21.4225;
    public static final double KAABA_LNG = 39.8262;
    public static final double EARTH_RADIUS_M = 6371000.0;
    /** Closer than this to the Kaaba the bearing is meaningless. */
    public static final double AT_KAABA_M = 100.0;

    /* Display rotation constants == android.view.Surface.ROTATION_*. */
    public static final int ROTATION_0 = 0, ROTATION_90 = 1, ROTATION_180 = 2, ROTATION_270 = 3;

    /* ------------------------------------------------------------------ */
    /* 1. Geographic part                                                  */
    /* ------------------------------------------------------------------ */

    public static boolean isValidLatLng(double lat, double lng) {
        return !Double.isNaN(lat) && !Double.isNaN(lng) && !Double.isInfinite(lat) && !Double.isInfinite(lng)
                && lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180;
    }

    public static double normalizeDeg(double d) {
        double r = d % 360.0;
        if (r < 0) r += 360.0;
        // guard -0.0 / 360.0 produced by rounding
        return r >= 360.0 ? 0.0 : r;
    }

    /** Signed shortest rotation from a to b in (-180, 180]. */
    public static double shortestDelta(double a, double b) {
        double d = (b - a) % 360.0;
        if (d > 180.0) d -= 360.0;
        if (d <= -180.0) d += 360.0;
        return d;
    }

    /** Initial great-circle bearing (degrees clockwise from TRUE north) from (lat,lng) to the Kaaba. NaN if invalid. */
    public static double qiblaBearing(double lat, double lng) {
        if (!isValidLatLng(lat, lng)) return Double.NaN;
        double phi1 = Math.toRadians(lat), phi2 = Math.toRadians(KAABA_LAT);
        double dLambda = Math.toRadians(KAABA_LNG - lng);
        double y = Math.sin(dLambda) * Math.cos(phi2);
        double x = Math.cos(phi1) * Math.sin(phi2) - Math.sin(phi1) * Math.cos(phi2) * Math.cos(dLambda);
        return normalizeDeg(Math.toDegrees(Math.atan2(y, x)));
    }

    /** Great-circle (haversine) distance in metres. */
    public static double distanceMeters(double lat1, double lng1, double lat2, double lng2) {
        double p1 = Math.toRadians(lat1), p2 = Math.toRadians(lat2);
        double dp = p2 - p1, dl = Math.toRadians(lng2 - lng1);
        double a = Math.sin(dp / 2) * Math.sin(dp / 2) + Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2) * Math.sin(dl / 2);
        return EARTH_RADIUS_M * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    }

    public static boolean isAtKaaba(double lat, double lng) {
        return isValidLatLng(lat, lng) && distanceMeters(lat, lng, KAABA_LAT, KAABA_LNG) < AT_KAABA_M;
    }

    /* ------------------------------------------------------------------ */
    /* 3. Relative angle (kept separate from 1 and 2)                      */
    /* ------------------------------------------------------------------ */

    /** Signed angle in (-180,180]: positive = Qibla is to the user's RIGHT (turn clockwise). */
    public static double relativeQiblaAngle(double absoluteBearing, double deviceHeading) {
        return shortestDelta(deviceHeading, absoluteBearing);
    }

    /** Magnetic -> true north. GeomagneticField.getDeclination() is positive when magnetic north is EAST of true north. */
    public static double applyDeclination(double magneticHeading, double declinationDeg) {
        return normalizeDeg(magneticHeading + declinationDeg);
    }

    /* ------------------------------------------------------------------ */
    /* 2. Device heading from a rotation matrix                            */
    /* ------------------------------------------------------------------ */

    /**
     * Re-expresses a device->world matrix in the frame of the DISPLAY, so that
     * "screen up" is the +Y axis whatever the current display rotation.
     * Equivalent to SensorManager.remapCoordinateSystem with
     *   ROTATION_0:   (X,  Y)    ROTATION_90:  (Y, -X)
     *   ROTATION_180: (-X, -Y)   ROTATION_270: (-Y, X)
     */
    public static float[] remapForDisplay(float[] r, int displayRotation) {
        float[] o = new float[9];
        int xc, yc;      // source column used as the new X / Y axis
        float xs, ys;    // and its sign
        switch (displayRotation) {
            case ROTATION_90:  xc = 1; xs = 1;  yc = 0; ys = -1; break;
            case ROTATION_180: xc = 0; xs = -1; yc = 1; ys = -1; break;
            case ROTATION_270: xc = 1; xs = -1; yc = 0; ys = 1;  break;
            default:           xc = 0; xs = 1;  yc = 1; ys = 1;  break;
        }
        for (int row = 0; row < 3; row++) {
            o[row * 3]     = xs * r[row * 3 + xc];
            o[row * 3 + 1] = ys * r[row * 3 + yc];
            o[row * 3 + 2] = r[row * 3 + 2]; // screen normal is unchanged by an in-plane rotation
        }
        return o;
    }

    /** Result of {@link #headingFromMatrix}. azimuth is clockwise from MAGNETIC north when r comes from a magnetic sensor. */
    public static final class Heading {
        public final double azimuth;    // 0..360
        public final double tiltDeg;    // angle between screen normal and vertical: 0 = flat face-up, 90 = upright, 180 = face-down
        public final double backWeight; // 0 = pure screen-up direction (phone flat) ... 1 = pure back-of-phone direction (upright)
        public final boolean reliable;
        Heading(double a, double t, double w, boolean ok) { azimuth = a; tiltDeg = t; backWeight = w; reliable = ok; }
    }

    private static final double FLAT_UNTIL_DEG = 45.0;    // below: heading = where the top of the screen points
    private static final double UPRIGHT_FROM_DEG = 75.0;  // above: heading = where the back of the phone points
    private static final double FACE_DOWN_DEG = 120.0;    // beyond: screen faces the ground, no honest heading
    private static final double MIN_HORIZONTAL = 0.15;    // reference axis must have >= this horizontal component

    /**
     * Tilt-compensated heading from a REMAPPED (see remapForDisplay) matrix.
     *
     * Held flat the heading is the direction of the screen's top edge,
     * atan2(East, North) of device +Y = atan2(r[1], r[4]). That axis becomes
     * vertical (undefined) when the phone is stood upright, so over a smooth tilt
     * range 45..75 degrees the answer is blended - as unit vectors, never raw
     * angles - into the direction the BACK of the phone faces (device -Z),
     * atan2(-r[2], -r[5]). This is the "look through the phone" heading.
     */
    public static Heading headingFromMatrix(float[] r) {
        if (r == null || r.length < 9) return new Heading(0, 0, 0, false);
        double tilt = Math.toDegrees(Math.acos(Math.max(-1.0, Math.min(1.0, r[8]))));
        double topE = r[1], topN = r[4];
        double backE = -r[2], backN = -r[5];
        double topH = Math.hypot(topE, topN), backH = Math.hypot(backE, backN);

        double t = Math.max(0.0, Math.min(1.0, (tilt - FLAT_UNTIL_DEG) / (UPRIGHT_FROM_DEG - FLAT_UNTIL_DEG)));
        double w = t * t * (3 - 2 * t); // smoothstep
        boolean topOk = topH >= MIN_HORIZONTAL, backOk = backH >= MIN_HORIZONTAL;
        double wt = topOk ? (1 - w) : 0, wb = backOk ? w : 0;

        double e, n;
        if (wt + wb > 0) {
            e = (topOk ? wt * topE / topH : 0) + (backOk ? wb * backE / backH : 0);
            n = (topOk ? wt * topN / topH : 0) + (backOk ? wb * backN / backH : 0);
        } else { // neither axis trustworthy: report the better one, flagged unreliable
            if (topH >= backH) { e = topE; n = topN; } else { e = backE; n = backN; }
        }
        double az = normalizeDeg(Math.toDegrees(Math.atan2(e, n)));
        boolean ok = (wt + wb) > 0 && tilt < FACE_DOWN_DEG && Math.hypot(e, n) > 0.2;
        return new Heading(az, tilt, w, ok);
    }

    /* ------------------------------------------------------------------ */
    /* Smoothing                                                           */
    /* ------------------------------------------------------------------ */

    /**
     * Low-pass filter for an angle. Filters the unit vector (sin, cos) so the
     * 359 -> 1 degree wrap-around can never produce a spurious sweep through 180.
     * Smoothing factor rises with the size of the jump so fast, genuine turns
     * are followed without lag while jitter is suppressed.
     */
    public static final class CircularFilter {
        private double x, y;
        private boolean init;
        private final double slow, fast;
        public CircularFilter(double slow, double fast) { this.slow = slow; this.fast = fast; }
        public CircularFilter() { this(0.18, 0.65); }
        public void reset() { init = false; }
        public double update(double deg) {
            double rx = Math.sin(Math.toRadians(deg)), ry = Math.cos(Math.toRadians(deg));
            if (!init) { x = rx; y = ry; init = true; return normalizeDeg(deg); }
            double cur = Math.toDegrees(Math.atan2(x, y));
            double jump = Math.abs(shortestDelta(cur, deg));
            double a = slow + (fast - slow) * Math.min(1.0, jump / 40.0);
            x += a * (rx - x);
            y += a * (ry - y);
            return normalizeDeg(Math.toDegrees(Math.atan2(x, y)));
        }
    }

    /* ------------------------------------------------------------------ */
    /* Sensor-health helpers                                               */
    /* ------------------------------------------------------------------ */

    /**
     * True when the measured field magnitude is implausible for the location
     * (steel hull, engine, speaker magnet...). Heuristic: outside 60%..150% of
     * the geomagnetic model's expected strength, or outside Earth's 20..80 uT range
     * when no model value is known.
     */
    public static boolean magneticInterference(double measuredUT, double expectedUT) {
        if (Double.isNaN(measuredUT) || measuredUT <= 0) return false;
        if (expectedUT > 0) {
            double ratio = measuredUT / expectedUT;
            return ratio < 0.6 || ratio > 1.5;
        }
        return measuredUT < 20.0 || measuredUT > 80.0;
    }
}
