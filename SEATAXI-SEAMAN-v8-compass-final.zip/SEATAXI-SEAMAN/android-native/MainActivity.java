package com.azamseataxi.seaman;
import android.os.Bundle;import com.getcapacitor.BridgeActivity;
public class MainActivity extends BridgeActivity{ @Override public void onCreate(Bundle b){registerPlugin(SeataxiLocationPlugin.class);registerPlugin(SeataxiFilesPlugin.class);registerPlugin(SeataxiCompassPlugin.class);super.onCreate(b);} }
