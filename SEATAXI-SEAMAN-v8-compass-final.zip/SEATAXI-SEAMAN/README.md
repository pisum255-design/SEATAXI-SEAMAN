# SEATAXI SEAMAN — Android project

Offline-first maritime operations app, Capacitor Android project.
Build the APK via the included GitHub Actions workflow (`.github/workflows/build-android.yml`) — no local Android SDK needed.

## This pass covers (not exhaustive — see gaps below)

- Native SQLite-backed trip-detection engine (new `android-native/TripDb.java`),
  moved out of JS-only execution into `LocationForegroundService` so trips are
  detected and durably persisted even while the WebView is suspended/killed.
  JS reconciles via `SeataxiLocation.getPersistedTrips()` on resume/visibility
  change and a live `tripPersisted` broadcast — exactly one authoritative
  engine (native), JS's own geofence logic now only runs as a non-native
  fallback.
- `FusedLocationProviderClient` (~750ms), monotonic elapsedRealtime ordering,
  `START_REDELIVER_INTENT`.
- Integer-only, truncated (not rounded) speedometer display.
- Global time display is HH:mm, no seconds (internal timestamps unchanged).
- THEME renamed, exactly Light Mode/Dark Mode/System (old 4th "redblue"
  option removed, migrated to Light for existing users).
- Bunkering is its own event type with fuel fields, not an emergency.
- Role-specific bottom nav: SKIPPER = Dashboard/Activity/Settings,
  OS = Dashboard/Wire/Settings. Activity = Reports + Trip History toggle.
- Boat Requirements removed from Skipper; OS dashboard has the 4 floating
  shortcuts (Badili Boti/Mahitaji ya Boti/Map/Imani).
- IMANI → Dua/Qibla chooser; Qibla is a new, honestly-labeled best-effort
  compass (GPS bearing + device compass), not a pre-existing feature.
- MAP is a new offline schematic (DAR/KIGAMBONI/vessel position plot) — this
  project has no bundled map tiles and must stay offline, so a real
  slippy map could not be built; this is a disclosed substitute, not the
  "existing map interface" the brief assumed exists.
- Reports: three-dot (⋯) menu with VIEW/EDIT/PDF/PHOTO/CSV/DELETE
  (PHOTO replaces "JPG" as the user-facing label).
- Preconfigured DAR/KIGAMBONI stations at the exact coordinates given,
  stored centrally; manual GPS calibration is now optional, not required.

## Latest changes (this delivery)

- **OS Watch Speed root-cause fix (native):** `LocationForegroundService.onStartCommand()` treated `cutoff=0` (which means "no expiry" everywhere else in that file) as "already expired," so OS's Watch Speed only ever worked by coincidence when a skipper operation with a real cutoff also happened to be active. Fixed with a `cutoff>0 &&` guard — OS now works standalone, regardless of any operation state.
- Wire Status maintenance-reminder note is now collapsed by default, revealed by tapping the section header.
- Skipper dashboard floating shortcuts redesigned into a 4-box grid (Matukio ya Dharura / Badilisha Boti / Map / Imani), matching the provided reference layout. Primary operation controls/trip stats above it are unchanged.
- GPS "Turn on location" style messaging now only shows while an operation (or OS Watch Speed) is actually running, never before, and distinguishes off vs weak signal. The literal wording was changed away from "Washa location"/"Turn on location" per request.
- Report completion bug fixed at the root: `pendingReportOperationId` is a single-slot pointer, so an older auto-closed operation reached via "Edit" could never be marked complete even after being fully filled in and saved. Completion now depends on the save action itself, not which UI path reached it.
- PDF Trip History route arrows no longer render as "?" — the hand-written PDF's Base-14 font can't encode "→", so it's now drawn with PDF vector primitives instead.
- Added a real one-step Android/in-app Back navigation stack (History day detail → Activity, Dua/Qibla → Imani, etc.) instead of always jumping to Dashboard.
- Added a Recycle Bin (Settings → Recycle Bin): Reports and History deletions are now reversible for 30 days (real timestamp-based expiry, verified with simulated dates — see prior phase notes), sorted by original record date.
- Manual GPS terminal calibration removed entirely. DAR/KIGAMBONI coordinates are now always the fixed values (-6.8198110, 39.2971348 / -6.8214981, 39.3014589), unconditionally, for every boat — no user input, no override path.
- Qibla screen rebuilt as a large custom SVG compass with correct spherical bearing math (verified against published reference bearings) and proper dial-rotation convention.

## Known gaps (disclosed, not silently skipped)

- GPS status Part 2 refinements (distinguishing location-service-enabled vs
  permission vs tracking-session state as six separate signals) were only
  partially addressed — the existing gpsAvailable-based messaging was kept.
- Event/incident history list screen (Part 6) and Trip History individual
  delete (Part 7) were not added in this pass.
- Elevated floating bottom nav (Part 16) got CSS styling (rounded, shadow,
  inset) but not a full redesign pass.
- Part 5 (auto-closed report completion) was already fixed in an earlier
  pass via the `reportCompleted` flag; re-verified logic is intact, not
  re-tested end to end here.

## Verification status

No Android SDK/network in this environment — `npm install` / `cap sync` /
`gradlew assembleDebug` could not be run here. Every JS change was verified
with `node --check` plus duplicate-key/duplicate-function/missing-translation
scans (all clean). The native `TripDb`/`LocationForegroundService` changes
were hand-reviewed against the FusedLocationProviderClient and SQLiteOpenHelper
APIs but not compiled — this is the highest-risk unverified part of this
delivery. First real build verification is the GitHub Actions run.

## Qibla compass repair

**Root causes found in the previous implementation** (all in the WebView `deviceorientation` path):

1. Two listeners (`deviceorientationabsolute` *and* relative `deviceorientation`) wrote the same heading variable. The relative event has an arbitrary zero, so the dial alternated between unrelated headings and was still treated as Earth-referenced once any absolute sample had been seen.
2. Heading was `360 - alpha`, valid only with the phone perfectly flat. Tilting the phone, or holding it upright, gave wrong headings (no tilt compensation).
3. No display-rotation handling: Chromium reports angles in the device's natural frame, so landscape was off by 90/180/270 degrees.
4. No magnetic declination: heading was magnetic-north, the Qibla bearing true-north, so the arrow was wrong by the local declination (up to ~20 degrees in some regions).
5. No sensor-quality handling (accuracy, magnetic interference), a one-shot GPS fix that was never retried or refreshed, and no native lifecycle control.

The geographic bearing formula itself was already correct; it is retained, now mirrored and tested against an independent n-vector implementation.

**What changed**

- `android-native/QiblaMath.java` - pure-Java math: Qibla bearing, display remap, tilt-compensated heading (flat = top edge, upright = back of phone, smooth blend), circular low-pass, declination, interference heuristic.
- `android-native/SeataxiCompassPlugin.java` - new Capacitor plugin `SeataxiCompass`: `TYPE_ROTATION_VECTOR` -> `getRotationMatrixFromVector` -> display remap -> filtered azimuth -> + `GeomagneticField` declination (offline). Falls back to accelerometer+magnetometer. Reports accuracy, interference and reliability. Sensors attach only between `start()`/`stop()` and only while the activity is resumed.
- `www/index.html` - Qibla screen keeps its existing SVG dial, but now keeps **absolute bearing**, **device heading** and **relative angle** as separate values, adds a "Turn right/left N" readout and status messages (calibrate, interference, hold level, magnetic-only). Browser fallback uses only `deviceorientationabsolute`, through the same matrix pipeline.
- Offline: no network use anywhere; declination uses Android's built-in model.

**Tests** - `npm test` (JS math extracted from `index.html` + Java `QiblaMath`), `npm run test:ui` (headless Chromium, mocked native plugin; needs Playwright).
