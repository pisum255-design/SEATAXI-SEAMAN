// OS Boat Requirements page, OS/Skipper independent recycle bins, report<->history sync, equal shortcut cards.
import { createRequire } from 'node:module';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const require = createRequire(import.meta.url);
const { chromium } = require(process.env.PLAYWRIGHT_PATH || 'playwright');
const here = path.dirname(fileURLToPath(import.meta.url));
let pass = 0, fail = 0;
const ok = (n, c, x='') => { if (c) pass++; else { fail++; console.log('FAIL ' + n + ' ' + x); } };

const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 376, height: 800 } });
const errors = []; page.on('pageerror', e => errors.push(String(e)));
await page.addInitScript(() => { window.Capacitor = { isNativePlatform: () => false, Plugins: {} }; });
await page.goto('file://' + path.join(here, '..', 'www', 'index.html')); await page.waitForTimeout(400);

await page.evaluate(() => {
  state.permissionsIntroShown = true; state.profile = { name: 'Ibrahim', rank: 'OS', photo: null }; state.settings.language = 'en';
  state.currentBoat = 'SEATAXI V';
  const b = ensureBoat('SEATAXI V');
  b.requirements['2026-10'] = [{ id: 'a1', item: 'Engine oil', qty: '2', unit: 'L', notes: 'SAE 40', date: '2026-10-01' }, { id: 'a2', item: 'Rope', qty: '1', unit: 'pcs', notes: '', date: '2026-10-02' }];
  b.requirements['2026-09'] = [{ id: 'b1', item: 'Life jackets', qty: '4', unit: 'pcs', notes: '', date: '2026-09-02' }];
  nav.tab = 'dashboard'; nav.subview = null; navStack = []; render();
});
await page.waitForTimeout(300);

// ---- 1. four shortcut cards identical size
const boxes = await page.evaluate(() => [...document.querySelectorAll('.os-eq .shortcut-btn')].map(e => { const r = e.getBoundingClientRect(); return [Math.round(r.width * 10) / 10, Math.round(r.height * 10) / 10]; }));
ok('4 cards', boxes.length === 4);
ok('equal widths', new Set(boxes.map(b => b[0])).size === 1, JSON.stringify(boxes));
ok('equal heights', new Set(boxes.map(b => b[1])).size === 1, JSON.stringify(boxes));
// same height as the Skipper dashboard shortcut cards
const skipperH = await page.evaluate(() => { const keep = state.profile.rank; state.profile.rank = 'SKIPPER'; nav.tab = 'dashboard'; render(); const h = [...document.querySelectorAll('.shortcuts-grid-4 .shortcut-btn')].map(e => Math.round(e.getBoundingClientRect().height * 10) / 10); state.profile.rank = keep; render(); return h; });
ok('OS card height == Skipper card height', skipperH.length === 4 && boxes.every(b => b[1] === skipperH[0]), JSON.stringify({ boxes, skipperH }));
// layout order from the reference: wire status -> WATCH SPEED banner -> 4 shortcuts
const order = await page.evaluate(() => { const r = document.getElementById('screenRoot'); return [...r.children].map(e => e.classList.contains('wire-ref') ? 'wire' : e.querySelector && e.querySelector('.watch-banner') ? 'banner' : e.classList.contains('os-eq') ? 'shortcuts' : 'other'); });
ok('order wire>banner>shortcuts', JSON.stringify(order) === '["wire","banner","shortcuts"]', JSON.stringify(order));
ok('no wire action buttons on OS dashboard', await page.$('#replaceWireBtn') === null && await page.$('#editWireBtn') === null);
const fs = await page.evaluate(() => { const os = [...document.querySelectorAll('.os-eq .shortcut-btn span:last-child')].map(e => getComputedStyle(e).fontSize + '/' + getComputedStyle(e).fontWeight); const keep = state.profile.rank; state.profile.rank = 'SKIPPER'; render(); const sk = [...document.querySelectorAll('.shortcuts-grid-4 .shortcut-btn span:last-child')].map(e => getComputedStyle(e).fontSize + '/' + getComputedStyle(e).fontWeight); state.profile.rank = keep; render(); return { os, sk }; });
ok('OS card font size/weight == Skipper', new Set(fs.os.concat(fs.sk)).size === 1, JSON.stringify(fs));
ok('card says BOAT NEEDS', /BOAT\s+NEEDS/i.test(await page.$eval('#osShReq', e => e.textContent)) && !/REQUIREMENTS/i.test(await page.$eval('#osShReq', e => e.textContent)));
ok('banner text has no emoji', !/[\u{1F300}-\u{1FAFF}]/u.test(await page.$eval('.watch-banner', e => e.textContent)));
ok('wire pill uses dot', await page.$('.wire-pill i') !== null);
const overflow = await page.evaluate(() => [...document.querySelectorAll('.os-eq .shortcut-btn span:last-child')].some(e => e.scrollWidth > e.clientWidth + 1));
ok('no label overflow', !overflow);
await page.screenshot({ path: '/tmp/os-dash.png' });

await page.evaluate(() => { nav.tab = 'wire'; render(); }); ok('Wire tab keeps wire actions', await page.$('#replaceWireBtn') !== null && await page.$('#editWireBtn') !== null); await page.evaluate(() => { nav.tab = 'dashboard'; render(); });
// ---- 2. Boat Requirements opens a page listing months
await page.click('#osShReq'); await page.waitForTimeout(200);
ok('page tab', await page.evaluate(() => nav.tab) === 'boatreq');
let rows = await page.$$eval('.list-item .list-title', els => els.map(e => e.textContent));
ok('months listed newest first', rows.includes('October 2026') && rows.includes('September 2026') && rows.indexOf('October 2026') < rows.indexOf('September 2026'), JSON.stringify(rows));
await page.screenshot({ path: '/tmp/os-req.png' });
// tap a month -> its requirements
await page.click('.list-item .list-main'); await page.waitForTimeout(200);
let items = await page.$$eval('.list-item .list-title', els => els.map(e => e.textContent));
ok('month detail lists items', items.includes('Engine oil') && items.includes('Rope'), JSON.stringify(items));
const headTxt = await page.$eval('.req-head', e => e.textContent);
ok('detail header has boat, month, OS', /SEATAXI V/.test(headTxt) && /October 2026/.test(headTxt) && /Ibrahim/.test(headTxt), headTxt);
ok('detail header has logo', await page.$('.req-head img') !== null);
await page.screenshot({ path: '/tmp/os-req-detail.png' });
// system back returns to the month list, then dashboard
await page.evaluate(() => handleSystemBack()); await page.waitForTimeout(150);
ok('back -> month list', await page.evaluate(() => nav.tab === 'boatreq' && !nav.subview));

// ---- 3. 3-dot menu: View / Share / Delete
await page.click('.list-item [data-menu-btn]'); await page.waitForTimeout(100);
const menuTxt = await page.$$eval('.report-row-menu button', els => els.map(e => e.textContent.trim()));
ok('menu = view/share/delete', JSON.stringify(menuTxt) === JSON.stringify(['View', 'SHARE', 'DELETE']), JSON.stringify(menuTxt));
await page.screenshot({ path: '/tmp/os-req-menu.png' });
// share offers exactly PDF / PHOTO
await page.click('.report-row-menu [data-act="share"]'); await page.waitForTimeout(150);
ok('share has PDF + PHOTO', await page.$('#reqSharePdf') !== null && await page.$('#reqSharePhoto') !== null);
// capture exports
await page.evaluate(() => { window.__saved = []; FileService.save = async (blob, name, mime) => { const buf = new Uint8Array(await blob.arrayBuffer()); window.__saved.push({ name, mime, size: blob.size, head: Array.from(buf.slice(0, 5)), txt: new TextDecoder('latin1').decode(buf) }); return { ok: true }; }; });
await page.click('#reqSharePdf'); await page.waitForTimeout(500);
let saved = await page.evaluate(() => window.__saved.map(s => ({ name: s.name, mime: s.mime, size: s.size, magic: String.fromCharCode(...s.head), hasBoat: s.txt.includes('SEATAXI V'), hasMonth: s.txt.includes('October 2026'), hasOS: s.txt.includes('Ibrahim'), hasLogo: s.txt.includes('/Subtype /Image'), hasItem: s.txt.includes('Engine oil') })));
ok('pdf saved', saved.length === 1 && saved[0].mime === 'application/pdf' && saved[0].magic.startsWith('%PDF'), JSON.stringify(saved));
ok('pdf has boat+month+OS+logo+items', saved[0] && saved[0].hasBoat && saved[0].hasMonth && saved[0].hasOS && saved[0].hasLogo && saved[0].hasItem, JSON.stringify(saved));
await page.evaluate(() => closeModal());
await page.click('.list-item [data-menu-btn]'); await page.click('.report-row-menu [data-act="share"]'); await page.click('#reqSharePhoto'); await page.waitForTimeout(900);
saved = await page.evaluate(() => window.__saved.map(s => ({ name: s.name, mime: s.mime, size: s.size })));
ok('photo saved as jpeg', saved.length === 2 && saved[1].mime === 'image/jpeg' && saved[1].size > 5000 && /\.jpg$/.test(saved[1].name), JSON.stringify(saved));
await page.evaluate(() => closeModal());

// ---- 4. delete -> OS recycle bin; restore
await page.click('.list-item [data-menu-btn]'); await page.click('.report-row-menu [data-act="delete"]'); await page.waitForTimeout(100);
await page.click('#confirmDelReq'); await page.waitForTimeout(200);
ok('month removed from boat', await page.evaluate(() => !state.boats['SEATAXI V'].requirements['2026-10']));
ok('OS bin has requirements entry', await page.evaluate(() => state.recycleBin.requirements.length === 1 && state.recycleBin.requirements[0].items.length === 2));
await page.evaluate(() => { nav.tab = 'recyclebin'; nav.subview = null; render(); }); await page.waitForTimeout(150);
const osBinTxt = await page.$eval('.card', e => e.textContent);
ok('OS bin shows month + boat', /October 2026/.test(osBinTxt) && /SEATAXI V/.test(osBinTxt), osBinTxt);
ok('OS bin has no Reports/History tabs', await page.$('#binReportsBtn') === null);
await page.screenshot({ path: '/tmp/os-bin.png' });

// ---- 5. independence: Skipper bin does not show OS items and vice versa
await page.evaluate(() => {
  state.operations['op1'] = { id: 'op1', boat: 'SEATAXI V', startTime: '2026-10-20T06:00:00.000Z', status: 'imekamilika', trips: [], incidents: [] };
  state.operations['op2'] = { id: 'op2', boat: 'SEATAXI V', startTime: '2026-10-21T06:00:00.000Z', status: 'imekamilika', trips: [], incidents: [] };
  state.profile.rank = 'SKIPPER'; nav.tab = 'recyclebin'; render();
});
await page.waitForTimeout(150);
ok('skipper bin shows tabs', await page.$('#binReportsBtn') !== null);
ok('skipper bin does not show OS requirements', !/October 2026|Engine oil/.test(await page.$eval('#screenRoot', e => e.textContent)));
// delete from REPORTS side -> appears in both tabs
await page.evaluate(() => { moveOperationToRecycleBin(state.operations['op1'], 'reports'); render(); });
let tabs = await page.evaluate(() => [state.recycleBin.reports.map(e => e.opId), state.recycleBin.history.map(e => e.opId)]);
ok('report delete -> also in history bin', JSON.stringify(tabs) === '[["op1"],["op1"]]', JSON.stringify(tabs));
ok('op removed', await page.evaluate(() => !state.operations['op1']));
// delete from HISTORY side -> appears in both tabs
await page.evaluate(() => { moveOperationToRecycleBin(state.operations['op2'], 'history'); render(); });
tabs = await page.evaluate(() => [state.recycleBin.reports.map(e => e.opId).sort(), state.recycleBin.history.map(e => e.opId).sort()]);
ok('history delete -> also in report bin', JSON.stringify(tabs) === '[["op1","op2"],["op1","op2"]]', JSON.stringify(tabs));
// both tabs render both entries
for (const tab of ['reports', 'history']) {
  await page.evaluate(t => { recycleBinSubTab = t; render(); }, tab);
  const n = await page.$$eval('.bin-row', e => e.length); ok('tab ' + tab + ' shows 2 rows', n === 2, String(n));
}
await page.screenshot({ path: '/tmp/skipper-bin.png' });
// restore from the HISTORY tab -> returns for both
await page.evaluate(() => { recycleBinSubTab = 'history'; render(); });
await page.click('.bin-row [data-restore]'); await page.waitForTimeout(100);
let st = await page.evaluate(() => ({ ops: Object.keys(state.operations).sort(), r: state.recycleBin.reports.length, h: state.recycleBin.history.length }));
ok('restore from history restores report too', st.ops.length === 1 && st.r === 1 && st.h === 1, JSON.stringify(st));
// restore remaining from REPORTS tab
await page.evaluate(() => { recycleBinSubTab = 'reports'; render(); });
await page.click('.bin-row [data-restore]'); await page.waitForTimeout(100);
st = await page.evaluate(() => ({ ops: Object.keys(state.operations).sort(), r: state.recycleBin.reports.length, h: state.recycleBin.history.length }));
ok('restore from reports restores history too', st.ops.length === 2 && st.r === 0 && st.h === 0, JSON.stringify(st));
// repeated delete/restore cycles never lose one side
for (let i = 0; i < 6; i++) {
  await page.evaluate(i => { const id = i % 2 ? 'op1' : 'op2'; moveOperationToRecycleBin(state.operations[id], i % 3 ? 'reports' : 'history'); }, i);
  await page.evaluate(i => { const id = i % 2 ? 'op1' : 'op2'; restoreFromRecycleBin(i % 3 ? 'history' : 'reports', id); }, i);
}
st = await page.evaluate(() => ({ ops: Object.keys(state.operations).length, r: state.recycleBin.reports.length, h: state.recycleBin.history.length }));
ok('multi-cycle consistency', st.ops === 2 && st.r === 0 && st.h === 0, JSON.stringify(st));
// legacy repair: only-history entry (old bug) is mirrored into reports
await page.evaluate(() => {
  const op = state.operations['op1']; delete state.operations['op1'];
  state.recycleBin.reports = []; state.recycleBin.history = [{ opId: 'op1', deletedAt: new Date().toISOString(), data: op }];
  purgeExpiredRecycleBinItems();
});
st = await page.evaluate(() => ({ r: state.recycleBin.reports.map(e => e.opId), h: state.recycleBin.history.map(e => e.opId) }));
ok('legacy one-sided entry repaired', JSON.stringify(st) === '{"r":["op1"],"h":["op1"]}', JSON.stringify(st));
// legacy: stale bin copy of a live operation is dropped
await page.evaluate(() => { restoreFromRecycleBin('reports', 'op1'); state.recycleBin.reports.push({ opId: 'op2', deletedAt: new Date().toISOString(), data: state.operations['op2'] }); normalizeRecycleBin(); });
ok('stale copy of live op dropped', await page.evaluate(() => state.recycleBin.reports.length === 0 && state.recycleBin.history.length === 0));

// ---- 6. OS restore (switch back to OS): independent state intact
await page.evaluate(() => { state.profile.rank = 'OS'; nav.tab = 'recyclebin'; render(); });
await page.waitForTimeout(100);
await page.click('.bin-row [data-restore]'); await page.waitForTimeout(100);
ok('OS restore returns month', await page.evaluate(() => (state.boats['SEATAXI V'].requirements['2026-10'] || []).length === 2 && state.recycleBin.requirements.length === 0));
// restore merges with items added after deletion (no loss, no duplicates)
await page.evaluate(() => {
  moveReqMonthToRecycleBin('SEATAXI V', '2026-10');
  state.boats['SEATAXI V'].requirements['2026-10'] = [{ id: 'n1', item: 'New', qty: '1', unit: '', notes: '', date: '2026-10-24' }];
  restoreReqMonthFromRecycleBin(state.recycleBin.requirements[0].id);
});
ok('restore merges', await page.evaluate(() => state.boats['SEATAXI V'].requirements['2026-10'].map(r => r.id).sort().join()) === 'a1,a2,n1');
ok('no page errors', errors.length === 0, errors.join('|'));
await browser.close();
console.log(`os-requirements-bin.test.mjs: ${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
