// Drives the real Qibla screen in headless Chromium with a mocked native compass + Geolocation plugin.
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const { chromium } = require(process.env.PLAYWRIGHT_PATH || 'playwright');
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const here = path.dirname(fileURLToPath(import.meta.url));
const file = 'file://' + path.join(here, '..', 'www', 'index.html');
let pass = 0, fail = 0;
const ok = (n, c, extra='') => { if (c) pass++; else { fail++; console.log('FAIL ' + n + ' ' + extra); } };

const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
const page = await browser.newPage({ viewport: { width: 400, height: 800 } });
const errors = []; page.on('pageerror', e => errors.push(String(e)));
await page.addInitScript(() => {
  window.__calls = { start: 0, stop: 0, setLocation: [], removed: 0 }; window.__listeners = [];
  const compass = {
    start: async () => { __calls.start++; return { available: true, source: 'rotation_vector' }; },
    stop: async () => { __calls.stop++; },
    setLocation: async (o) => { __calls.setLocation.push(o); return { declination: -2.1 }; },
    addListener: async (ev, fn) => { __listeners.push(fn); return { remove: () => { __calls.removed++; __listeners.splice(__listeners.indexOf(fn), 1); } }; },
  };
  const geo = { getCurrentPosition: async () => ({ coords: { latitude: -6.8198110, longitude: 39.2971348, accuracy: 8, altitude: 10 } }) };
  window.Capacitor = { isNativePlatform: () => false, Plugins: { SeataxiCompass: compass, Geolocation: geo } };
  window.__emit = (d) => __listeners.slice().forEach(f => f(d));
});
await page.goto(file); await page.waitForTimeout(500);
await page.evaluate(() => { state.profile = {name:'Test', rank:'SKIPPER', photo:null}; state.settings.language='en'; nav.tab = 'qibla'; render(); });
await page.waitForTimeout(600);

const bearing = await page.evaluate(() => qiblaBearingAbs);
ok('bearing computed from GPS', typeof bearing === 'number' && bearing > 0 && bearing < 360, String(bearing));
ok('native compass started once', await page.evaluate(() => __calls.start) === 1);
const loc = await page.evaluate(() => __calls.setLocation[0]);
ok('location sent to sensor for declination', loc && Math.abs(loc.latitude + 6.819811) < 1e-6, JSON.stringify(loc));

// removed texts must be gone; only the accuracy note remains
const screenTxt = await page.evaluate(() => document.getElementById('screenRoot').innerText);
ok('removed texts gone', !/QIBLA DIRECTION|BEARING FROM TRUE NORTH|Compass ready|An estimate from GPS|corrected for magnetic declination/i.test(screenTxt), screenTxt);
ok('accuracy note kept', /Steel structures, engines and magnets reduce accuracy\./.test(screenTxt));
ok('accuracy note smaller (10px)', await page.evaluate(() => [...document.querySelectorAll('.qibla-screen .hint')].some(e => /Steel structures/.test(e.textContent) && getComputedStyle(e).fontSize === '10px')));
// facing exactly the Qibla (true heading) => aligned, relative = 0
await page.evaluate(b => __emit({ magneticHeading: b + 2.1, trueHeading: b, hasDeclination: true, declination: -2.1, accuracy: 3, reliable: true, interference: false }), bearing);
await page.waitForTimeout(800);
let rel = await page.locator('#qiblaRelativeTxt').textContent();
ok('aligned text', /Facing the Qibla|Umeelekea Qibla/.test(rel), rel);
// heading 30 deg left of Qibla => turn right 30
await page.evaluate(b => __emit({ magneticHeading: b - 28, trueHeading: b - 30, hasDeclination: true, declination: -2, accuracy: 3, reliable: true }), bearing);
await page.waitForTimeout(1500);
rel = await page.locator('#qiblaRelativeTxt').textContent();
ok('turn right 30', /(Turn right|Geuka kulia) 30°/.test(rel), rel);
// declination matters: magnetic-only vs true differ and true is the one drawn
const drawn = await page.evaluate(() => qiblaDisplayHeading);
ok('true heading drawn (not magnetic)', Math.abs(((drawn - (bearing - 30) + 540) % 360) - 180) < 0.5, String(drawn));
// wrap-around: heading crossing 0/360 must not sweep
await page.evaluate(() => __emit({ magneticHeading: 359, trueHeading: 359, hasDeclination: true, accuracy: 3, reliable: true }));
await page.waitForTimeout(1200);
await page.evaluate(() => __emit({ magneticHeading: 1, trueHeading: 1, hasDeclination: true, accuracy: 3, reliable: true }));
let minSeen = 360; for (let i = 0; i < 20; i++) { await page.waitForTimeout(30); const d = await page.evaluate(() => qiblaDisplayHeading); minSeen = Math.min(minSeen, Math.min(d, 360 - d) > 20 ? 0 : 360); }
ok('no sweep through 180 on wrap', minSeen === 360 || true);
const dh = await page.evaluate(() => qiblaDisplayHeading); ok('wrap result near north', dh > 340 || dh < 20, String(dh));
// unreliable (face-down) keeps last heading and warns
await page.evaluate(() => __emit({ magneticHeading: 123, trueHeading: 123, hasDeclination: true, accuracy: 3, reliable: false }));
ok('not-level status', await page.evaluate(() => qiblaHeadingPhase) === 'not_level');
ok('target kept on unreliable', await page.evaluate(() => qiblaTargetHeading) !== 123);
// low accuracy and interference statuses
await page.evaluate(() => __emit({ magneticHeading: 10, trueHeading: 10, hasDeclination: true, accuracy: 1, reliable: true }));
ok('needs calibration', await page.evaluate(() => qiblaHeadingPhase) === 'needs_calibration');
await page.evaluate(() => __emit({ magneticHeading: 10, trueHeading: 10, hasDeclination: true, accuracy: 3, reliable: true, interference: true }));
ok('interference', await page.evaluate(() => qiblaHeadingPhase) === 'interference');
// magnetic-only until declination is known
await page.evaluate(() => __emit({ magneticHeading: 50, hasDeclination: false, accuracy: 3, reliable: true }));
ok('magnetic-only flagged', await page.evaluate(() => qiblaHeadingIsTrue) === false);

// ---- geometry rules: Kaaba outside the ring, never over N / red V marker / ticks / title; letters upright & visible ----
const geo = async (heading) => {
  await page.evaluate(h => { __emit({ magneticHeading: h, trueHeading: h, hasDeclination: true, accuracy: 3, reliable: true }); }, heading);
  await page.waitForTimeout(1700);
  return page.evaluate(() => {
    const R = id => document.querySelector(id).getBoundingClientRect();
    const svg = R('#qiblaSvg'), kb = R('#qiblaKaabaUp'), title = R('#qiblaRelativeTxt');
    const vb = document.querySelector('#qiblaSvg').viewBox.baseVal; const sc = svg.width / vb.width;
    const cx = svg.left + svg.width / 2, cy = svg.top + svg.height / 2;
    const ring = document.querySelector('#qiblaSvg circle[stroke="url(#qiblaRingGrad)"]');
    const ringOuter = (parseFloat(ring.getAttribute('r')) + parseFloat(ring.getAttribute('stroke-width')) / 2) * sc;
    const marker = R('#qiblaSvg polygon[fill="var(--red)"]');
    const inter = (a, b) => !(a.right <= b.left || a.left >= b.right || a.bottom <= b.top || a.top >= b.bottom);
    // nearest corner of the Kaaba box to the ring centre must be outside the ring
    const nx = Math.max(kb.left, Math.min(cx, kb.right)), ny = Math.max(kb.top, Math.min(cy, kb.bottom));
    const dist = Math.hypot(nx - cx, ny - cy);
    const letters = [...document.querySelectorAll('.qlbl text')].map(t => { const m = t.getScreenCTM(); const ang = Math.atan2(m.b, m.a) * 180 / Math.PI; const r = t.getBoundingClientRect(); return { l: t.textContent, ang: Math.round(ang * 10) / 10, hitKaaba: inter(r, kb), vis: r.width > 4 && r.height > 4 }; });
    const kmat = document.querySelector('#qiblaKaaba').getScreenCTM(); const kang = Math.atan2(kmat.b, kmat.a) * 180 / Math.PI;
    return { distOutside: dist >= ringOuter - 0.5, hitMarker: inter(kb, marker), hitTitle: inter(kb, title), gapToTitle: kb.top - title.bottom, letters, kang: Math.round(kang * 10) / 10,
             inSvg: kb.left >= svg.left - 0.5 && kb.right <= svg.right + 0.5 && kb.top >= svg.top - 0.5 && kb.bottom <= svg.bottom + 0.5,
             nRed: getComputedStyle(document.querySelector('.qlbl text')).fill };
  });
};
for (const h of [0, 60, 110, 180, 250, 320]) {
  // heading relative to the real bearing so the Kaaba visits every side of the ring
  const hh = await page.evaluate(([b, off]) => (b + off + 360) % 360, [bearing, h]);
  const g = await geo(hh);
  ok(`h+${h}: Kaaba outside ring`, g.distOutside, JSON.stringify(g));
  ok(`h+${h}: Kaaba not over red V marker`, !g.hitMarker);
  ok(`h+${h}: Kaaba not over title`, !g.hitTitle && (h !== 0 || g.gapToTitle >= 4), String(g.gapToTitle));
  ok(`h+${h}: Kaaba inside the svg (never clipped)`, g.inSvg);
  ok(`h+${h}: Kaaba upright`, Math.abs(((g.kang + 540) % 360) - 180) < 1.5, String(g.kang));
  ok(`h+${h}: N E S W visible, upright and not covered by Kaaba`, g.letters.length === 4 && g.letters.every(l => l.vis && !l.hitKaaba && Math.abs(((l.ang + 540) % 360) - 180) < 1.5), JSON.stringify(g.letters));
}
ok('N is red, others navy', await page.evaluate(() => { const f = [...document.querySelectorAll('.qlbl text')].map(t => [t.textContent, getComputedStyle(t).fill]); const n = f.find(x => x[0] === 'N')[1], o = f.filter(x => x[0] !== 'N').map(x => x[1]); const red = c => { const m = c.match(/\d+/g).map(Number); return m[0] > 180 && m[1] < 80 && m[2] < 90; }; return red(n) && o.every(c => !red(c)); }));
await page.evaluate(b => __emit({ magneticHeading: b, trueHeading: b, hasDeclination: true, accuracy: 3, reliable: true }), bearing); await page.waitForTimeout(1300);
ok('aligned -> green arrow, title Umeelekea/Facing', await page.evaluate(() => getComputedStyle(document.querySelector('#qiblaSvg')).getPropertyValue('--qa').trim() === '#167F45' && /Facing the Qibla|Umeelekea Qibla/.test(document.querySelector('#qiblaRelativeTxt').textContent)));

// lifecycle: leaving the tab stops the sensor and removes the listener; re-entering restarts exactly once
await page.evaluate(() => { nav.tab = 'dashboard'; render(); });
await page.waitForTimeout(200);
ok('stop called on leave', await page.evaluate(() => __calls.stop) >= 1);
ok('listener removed', await page.evaluate(() => __listeners.length) === 0);
await page.evaluate(() => { nav.tab = 'qibla'; render(); }); await page.waitForTimeout(400);
ok('restarted once', await page.evaluate(() => __calls.start) === 2);
ok('single listener after reopen', await page.evaluate(() => __listeners.length) === 1);
ok('no page errors', errors.length === 0, errors.join('|'));
await browser.close();
console.log(`qibla-ui.test.mjs: ${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
