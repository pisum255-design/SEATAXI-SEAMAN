package com.azamseataxi.seaman;

/** Dependency-free unit tests for QiblaMath (run: tests/run-tests.sh). Exit code 1 on any failure. */
public class QiblaMathTest {
    static int pass = 0, fail = 0;

    static void near(String name, double actual, double expected, double tol) {
        double d = Math.abs(QiblaMath.shortestDelta(expected, actual)); // circular-safe
        if (d <= tol) pass++; else { fail++; System.out.println("FAIL " + name + ": expected " + expected + " got " + actual + " (tol " + tol + ")"); }
    }
    static void nearLinear(String name, double actual, double expected, double tol) {
        if (Math.abs(actual - expected) <= tol) pass++; else { fail++; System.out.println("FAIL " + name + ": expected " + expected + " got " + actual); }
    }
    static void check(String name, boolean ok) { if (ok) pass++; else { fail++; System.out.println("FAIL " + name); } }

    /* ---------- independent reference: n-vector / cross-product method (different algorithm from QiblaMath) ---------- */
    static double[] nvec(double lat, double lng) {
        double p = Math.toRadians(lat), l = Math.toRadians(lng);
        return new double[]{Math.cos(p) * Math.cos(l), Math.cos(p) * Math.sin(l), Math.sin(p)};
    }
    static double[] cross(double[] a, double[] b) { return new double[]{a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]}; }
    static double dot(double[] a, double[] b) { return a[0]*b[0]+a[1]*b[1]+a[2]*b[2]; }
    static double nvectorBearing(double lat, double lng, double lat2, double lng2) {
        double[] a = nvec(lat, lng), b = nvec(lat2, lng2), np = {0, 0, 1};
        double[] c1 = cross(a, b), c2 = cross(a, np); // great-circle normal vs meridian normal
        double ang = Math.atan2(dot(cross(c1, c2), a), dot(c1, c2));
        return QiblaMath.normalizeDeg(Math.toDegrees(ang));
    }

    /* ---------- device attitude builders (W3C ZXY Euler -> device-to-world matrix, ENU) ---------- */
    static float[] mul(double[][] a, double[][] b) {
        float[] o = new float[9];
        for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) { double s = 0; for (int k = 0; k < 3; k++) s += a[i][k] * b[k][j]; o[i*3+j] = (float) s; }
        return o;
    }
    static double[][] to2(float[] f) { double[][] m = new double[3][3]; for (int i = 0; i < 9; i++) m[i/3][i%3] = f[i]; return m; }
    static double[][] rz(double d) { double c = Math.cos(Math.toRadians(d)), s = Math.sin(Math.toRadians(d)); return new double[][]{{c,-s,0},{s,c,0},{0,0,1}}; }
    static double[][] rx(double d) { double c = Math.cos(Math.toRadians(d)), s = Math.sin(Math.toRadians(d)); return new double[][]{{1,0,0},{0,c,-s},{0,s,c}}; }
    static double[][] ry(double d) { double c = Math.cos(Math.toRadians(d)), s = Math.sin(Math.toRadians(d)); return new double[][]{{c,0,s},{0,1,0},{-s,0,c}}; }
    /** Phone lying with screen up, top edge pointing at compass heading h, then tipped: pitch (top edge up) and roll. */
    static float[] attitude(double topHeading, double pitch, double roll) {
        float[] a = mul(rz(-topHeading), rx(pitch));
        return mul(to2(a), ry(roll));
    }
    /** Phone held upright, screen facing the user, user facing compass heading h. Columns = X,Y,Z device axes in ENU. */
    static float[] upright(double h) {
        double sx = Math.sin(Math.toRadians(h)), cx = Math.cos(Math.toRadians(h));
        double[] f = {sx, cx, 0}, up = {0, 0, 1}, z = {-f[0], -f[1], 0};
        double[] x = cross(up, z); // Y x Z = X
        return new float[]{(float)x[0], (float)up[0], (float)z[0], (float)x[1], (float)up[1], (float)z[1], (float)x[2], (float)up[2], (float)z[2]};
    }
    static double heading(float[] raw, int rot) { return QiblaMath.headingFromMatrix(QiblaMath.remapForDisplay(raw, rot)).azimuth; }

    public static void main(String[] args) {
        /* ===== 1. absolute Qibla bearing ===== */
        // published/commonly cited bearings (deg from true north), tolerance 0.6
        near("London", QiblaMath.qiblaBearing(51.5074, -0.1278), 118.9, 0.6);
        near("New York", QiblaMath.qiblaBearing(40.7128, -74.0060), 58.5, 0.6);
        near("Jakarta", QiblaMath.qiblaBearing(-6.2088, 106.8456), 295.1, 0.6);
        near("Sydney", QiblaMath.qiblaBearing(-33.8688, 151.2093), 277.5, 0.6);
        near("Cape Town", QiblaMath.qiblaBearing(-33.9249, 18.4241), 23.0, 1.0);
        near("Dar es Salaam", QiblaMath.qiblaBearing(-6.8198110, 39.2971348), nvectorBearing(-6.8198110, 39.2971348, QiblaMath.KAABA_LAT, QiblaMath.KAABA_LNG), 0.01);
        // exact algorithm cross-check on a grid of places
        double[][] grid = {{0,0},{60,10},{-45,-70},{35.7,139.7},{-1.29,36.82},{64.1,-21.9},{-54.8,-68.3},{10,170},{-10,-170},{30,39.8},{21.5,40.5}};
        for (double[] g : grid) near("grid " + g[0] + "," + g[1], QiblaMath.qiblaBearing(g[0], g[1]), nvectorBearing(g[0], g[1], QiblaMath.KAABA_LAT, QiblaMath.KAABA_LNG), 0.001);
        // cardinal sanity
        near("due south of Kaaba -> north", QiblaMath.qiblaBearing(10.0, QiblaMath.KAABA_LNG), 0.0, 0.01);
        near("due north of Kaaba -> south", QiblaMath.qiblaBearing(40.0, QiblaMath.KAABA_LNG), 180.0, 0.01);
        // a great circle from due west on the same parallel bows poleward, so the initial bearing is slightly NORTH of east (<90), not 90
        double wb = QiblaMath.qiblaBearing(QiblaMath.KAABA_LAT, 20.0);
        check("west on Kaaba parallel bows north of east: " + wb, wb > 85 && wb < 90);
        check("invalid lat", Double.isNaN(QiblaMath.qiblaBearing(91, 0)));
        check("invalid NaN", Double.isNaN(QiblaMath.qiblaBearing(Double.NaN, 0)));
        check("at kaaba", QiblaMath.isAtKaaba(21.4226, 39.8262));
        check("not at kaaba", !QiblaMath.isAtKaaba(21.5, 39.8262));
        nearLinear("distance London-Kaaba km", QiblaMath.distanceMeters(51.5074, -0.1278, 21.4225, 39.8262) / 1000.0, 4780, 40);

        /* ===== 2. angle helpers ===== */
        nearLinear("delta wrap", QiblaMath.shortestDelta(350, 10), 20, 1e-9);
        nearLinear("delta wrap neg", QiblaMath.shortestDelta(10, 350), -20, 1e-9);
        nearLinear("delta 180", QiblaMath.shortestDelta(0, 180), 180, 1e-9);
        nearLinear("normalize neg", QiblaMath.normalizeDeg(-10), 350, 1e-9);
        nearLinear("normalize 720", QiblaMath.normalizeDeg(725), 5, 1e-9);
        nearLinear("relative: facing N, qibla 90 -> right 90", QiblaMath.relativeQiblaAngle(90, 0), 90, 1e-9);
        nearLinear("relative: facing 90, qibla 90 -> aligned", QiblaMath.relativeQiblaAngle(90, 90), 0, 1e-9);
        nearLinear("relative: facing 350, qibla 10 -> right 20", QiblaMath.relativeQiblaAngle(10, 350), 20, 1e-9);
        nearLinear("relative: facing 10, qibla 350 -> left 20", QiblaMath.relativeQiblaAngle(350, 10), -20, 1e-9);
        near("declination east", QiblaMath.applyDeclination(350, 15), 5, 1e-9);
        near("declination west", QiblaMath.applyDeclination(5, -10), 355, 1e-9);
        // absolute bearing must be independent of heading, relative must be independent of declination reference choice
        double brg = QiblaMath.qiblaBearing(51.5074, -0.1278);
        nearLinear("bearing unchanged by heading", QiblaMath.qiblaBearing(51.5074, -0.1278), brg, 0);

        /* ===== 3. heading from rotation matrix ===== */
        for (int h = 0; h < 360; h += 15) {
            near("flat heading " + h, heading(attitude(h, 0, 0), 0), h, 0.01);
            // tilt compensation: tipping the phone up to 40 deg must not move the heading
            near("tilted 20 heading " + h, heading(attitude(h, 20, 0), 0), h, 0.05);
            near("tilted 40 heading " + h, heading(attitude(h, 40, 0), 0), h, 0.05);
            near("tilted -30 heading " + h, heading(attitude(h, -30, 0), 0), h, 0.05);
            // display rotation: phone physically turned, user still faces h
            near("rot90 heading " + h, heading(attitude(h + 90, 0, 0), QiblaMath.ROTATION_90), h, 0.01);
            near("rot180 heading " + h, heading(attitude(h + 180, 0, 0), QiblaMath.ROTATION_180), h, 0.01);
            near("rot270 heading " + h, heading(attitude(h - 90, 0, 0), QiblaMath.ROTATION_270), h, 0.01);
            // upright phone: heading is where the back of the phone points
            near("upright heading " + h, heading(upright(h), 0), h, 0.01);
            near("upright landscape(90) heading " + h, heading(mul(to2(upright(h)), rz(-90)), QiblaMath.ROTATION_90), h, 0.01);
        }
        QiblaMath.Heading flat = QiblaMath.headingFromMatrix(attitude(100, 0, 0));
        check("flat reliable", flat.reliable && flat.tiltDeg < 0.1 && flat.backWeight == 0);
        QiblaMath.Heading up = QiblaMath.headingFromMatrix(upright(100));
        check("upright reliable", up.reliable && Math.abs(up.tiltDeg - 90) < 0.1 && up.backWeight == 1);
        check("face-down unreliable", !QiblaMath.headingFromMatrix(attitude(100, 0, 180)).reliable);
        check("garbage matrix unreliable", !QiblaMath.headingFromMatrix(new float[9]).reliable);
        check("null matrix unreliable", !QiblaMath.headingFromMatrix(null).reliable);
        // continuity across the flat->upright blend: no jump bigger than 2 deg for a smooth tilt sweep
        double prev = heading(attitude(200, 0, 0), 0), worst = 0;
        for (double p = 0; p <= 90; p += 0.5) { double cur = heading(attitude(200, p, 0), 0); worst = Math.max(worst, Math.abs(QiblaMath.shortestDelta(prev, cur))); prev = cur; }
        check("blend continuity worst=" + worst, worst < 2.0);

        /* ===== 4. circular filter ===== */
        QiblaMath.CircularFilter f = new QiblaMath.CircularFilter();
        f.update(359);
        double out = f.update(1);
        check("filter crosses 0/360 without sweeping through 180: " + out, out > 350 || out < 10);
        QiblaMath.CircularFilter f2 = new QiblaMath.CircularFilter();
        double v = 0; for (int i = 0; i < 80; i++) v = f2.update(90);
        near("filter converges", v, 90, 0.01);
        QiblaMath.CircularFilter f3 = new QiblaMath.CircularFilter(); f3.update(10);
        double jitter = 0; for (int i = 0; i < 100; i++) jitter = Math.max(jitter, Math.abs(QiblaMath.shortestDelta(10, f3.update(10 + (i % 2 == 0 ? 2 : -2)))));
        check("filter damps +-2deg jitter: " + jitter, jitter < 2.0);

        /* ===== 5. interference ===== */
        check("normal field", !QiblaMath.magneticInterference(45, 45));
        check("hull field", QiblaMath.magneticInterference(120, 45));
        check("weak field", QiblaMath.magneticInterference(15, 45));
        check("no model normal", !QiblaMath.magneticInterference(48, 0));
        check("no model strong", QiblaMath.magneticInterference(95, 0));

        System.out.println("QiblaMathTest: " + pass + " passed, " + fail + " failed");
        System.exit(fail == 0 ? 0 : 1);
    }
}
